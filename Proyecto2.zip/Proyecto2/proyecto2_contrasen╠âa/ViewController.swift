//
//  ViewController.swift
//  proyecto2_contraseña
//
//  Created by Macbook on 08/10/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
    
//    func userDidEnterInformation(usuario: String, contraseña: String) {
//        print(usuario)
//        print(contraseña)
//        print("hola mundo")
//    }
    
    
    @IBOutlet weak var Usuario: UITextField!
    @IBOutlet weak var Contraseña: UITextField!
    @IBOutlet weak var Mensaje: UILabel!
    
    static var usuarios = [Usuarios]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Mensaje.text = ""
        
        ViewController.usuarios = [
            Usuarios(email: "micorreo@servidor.com", pass: "qwerty"),
            Usuarios(email: "ramiroesponja@hotmail.com", pass: "123456")
        ]
        
        print(ViewController.usuarios)
    }
    
//    @IBAction func crear(_ sender: Any) {
//        
//        
//        
//        
//    }
    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        let resumeSegue = CrearUsuarioViewController()
//        resumeSegue.delegado = self
//    }
    
    @IBAction func Ingresar(_ sender: UIButton) {
        let limite:Int = ViewController.usuarios.count
        let usuarioTxt = Usuario.text
        let contraseñaTxt = Contraseña.text
        print(ViewController.usuarios)
        
        for i in 0...limite - 1 {
            if ViewController.usuarios[i].email == usuarioTxt{
                if ViewController.usuarios[i].pass == contraseñaTxt{
                    print("Usuario Autenticado")
                    Mensaje.text = "Usuario Autenticado"
                    return
                }
            }
        }
        
        print("Usuario no encontrado")
        Mensaje.text = "Usuario no encontrado"
    }
    
    func updateData() {
        
    }
}

