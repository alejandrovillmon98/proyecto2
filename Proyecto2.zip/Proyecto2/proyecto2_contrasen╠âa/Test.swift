//
//  Test.swift
//  proyecto2_contraseña
//
//  Created by macbook on 10/19/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import Foundation

class Test {
    
    static var name = ""
    static var pwd = ""
}
