//
//  CrearUsuarioViewController.swift
//  proyecto2_contraseña
//
//  Created by macbook on 10/19/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

//protocol dataEnteredDelegate {
//    func userDidEnterInformation(usuario: String, contraseña: String)
//}

class CrearUsuarioViewController: UIViewController {
    
//    var delegado: dataEnteredDelegate?
    
    @IBOutlet weak var Email: UITextField!
    @IBOutlet weak var Contraseña: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func CrearUser(_ sender: Any) {
        
            guard let ingresaContraseña = Contraseña.text else { return }
            guard let ingresarUsuario = Email.text else { return }
            let user = Usuarios(email: ingresarUsuario, pass: ingresaContraseña)
            ViewController.usuarios.append(user)
            self.dismiss(animated: true, completion: nil)
            print(ViewController.usuarios)

    }
}
